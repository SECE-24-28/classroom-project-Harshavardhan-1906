import React from "react";

function Name()
{
    return(
        <h1>Hello React</h1>
    )
}
export default Name