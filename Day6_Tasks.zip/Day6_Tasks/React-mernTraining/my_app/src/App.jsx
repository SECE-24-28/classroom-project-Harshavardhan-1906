import React from 'react'
 function App()
 {
  return(
   <div>
    <h1>Hello</h1>
    <p>I'm Harshavardhan</p>
    <p>Currently persuing EEE degree</p>
    <p>At Sri Eshwar College of Engineering</p>
   </div>
  )
 }

export default App
